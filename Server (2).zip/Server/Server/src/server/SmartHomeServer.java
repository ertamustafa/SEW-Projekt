/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

/**
 *
 * @author Simona
 */
public class SmartHomeServer extends Thread{
    DataWrapper dW;
    Socket socket;
    public SmartHomeServer(){

		 
    }
    
    /**
     * 
     * @param socket,  
     */
    SmartHomeServer (Socket socket){
        this.socket = socket;
    }

    SmartHomeServer(DataWrapper dW) {
        this.dW = dW; 
        Scanner sc = new Scanner(System.in);
		boolean l = sc.nextBoolean();
                dW.setLight(l);
                System.out.println(dW.getLight(l));
                boolean t = sc.nextBoolean();
                dW.setTemperature(t);
                System.out.println(dW.getTemperature(t));
                String v = sc.nextLine();
                dW.setVentilator(v);
                System.out.println(dW.getVentilator(v));
   }
    
   public void run(){
       try {
           String m1 = null;
           PrintWriter printWriter = new PrintWriter(socket.getOutputStream(), true);
           BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
           System.out.println("Das Haus: " + bufferedReader.readLine() + "ist jetzt mit dem Server verbunden");
           while ((m1 = bufferedReader.readLine()) != null) {
               System.out.println("Das Haus schickt jetzt einen Nachricht: " + m1);
               printWriter.println("Der Server hallt den Nachricht wider: " + m1);
           }
           socket.close();
       }
     
       catch (IOException e){
           System.out.println(e);
       }
   }
    
    
}
