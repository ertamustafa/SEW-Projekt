/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

/**
 *
 * @author Simona
 */
public class DataWrapper {
    boolean light;
    boolean temperature;
    String ventilator;
    
    /**
     * 
     * @param light, das Licht einschalten oder ausschalten 
     * @return das Wert von Licht (on/off)
     */
    public boolean setLight(boolean light){
     return this.light = light;
   }
    
     /**
     * 
     * @param light
     * @return 
     */ 
   public boolean getLight(boolean light){
     return light;
   }
   
   /**
    * 
    * @param temperature
    * @return 
    */
   public boolean setTemperature(boolean temperature){
     return this.temperature = temperature;
   }
   
     /**
      * 
      * @param temperature
      * @return 
      */
   public boolean getTemperature(boolean temperature){
        return temperature;
    }
   
   
  
   /**
    * 
    * @param ventilator
    * @return 
    */
    public String setVentilator(String ventilator){
     return this.ventilator = ventilator;
   }
   
   /**
    * 
    * @param ventilator
    * @return 
    */
   public String getVentilator(String ventilator){
       return ventilator;
   }

    
 
}
